Free Social nightly-20261107 (build 0ee2a40, 2026-11-07)

This APK is a signed release build (not a debug build).

INSTALL (3 steps)
1. Extract the .apk from this zip and tap it. Allow install from this source.
2. FIRST RUN: the setup wizard leads you through:
   - "Allow restricted settings" (Android 13+): Free Social app-info menu ->
     Allow restricted settings. REQUIRED or the accessibility toggle is dead.
   - Enable "Content filtering" accessibility service.
   - Optional "Whole-app blocking" service, overlay + battery exemption.
3. Grant any remaining permissions the Permissions screen shows (live status).

WHAT'S NEW
See the release notes on GitHub for this build's changelog.

KNOWN ROUGH EDGES
- Per-app modes explain themselves on the mode screen ("takes effect when you open
  the app") — switching modes has no visible effect inside Free Social, that part is
  expected: the effect shows in the target app.
- TikTok DM carve-out: structurally matched, live check still pending.
- ColorOS: the capture notification may not render in the shade (in-app step card
  is the guide there); hub budget can read stale until app restart (decisions always
  use live values).

Report anything that leaks a reel or over-blocks in the repo's issue tracker.
